<?php include_once("../includes/header.php") ?>
<br>
<h3>Training Module</h3>
<br>
<br>
<form action="uploads.php" method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleFormControlSelect1">Select Department</label>
    <select class="form-control" id="selectdepartment" name="department">
      <option>BCA</option>
      <option>CSE</option>
      <option>IT</option>
      <option>Mechanical</option>
      <option>ECE</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Company Name</label>
    <input type="text" class="form-control" name="companyname1" aria-describedby="companyname" placeholder="company name">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Training On</label>
    <input type="text" class="form-control" name="traningtopic1" aria-describedby="companyname" placeholder="Training Topic">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Prerequisites</label>
    <input type="text" class="form-control" name="prerequisites" aria-describedby="companyname" placeholder="prerequisites for training">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Training details (pdf upload here)</label>
    <input type="file" name="file">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Starting Date</label>
    <input type="text" class="form-control" name="startdate" aria-describedby="companyname" placeholder="dd/mm/yyyy">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Tenure of Training </label>
    <input type="text" class="form-control" name="trainingtime" aria-describedby="companyname" placeholder="training time period">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Contact details of Company</label>
    <input type="text" class="form-control" name="companycontact" aria-describedby="companyname" placeholder="contact delaits">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Notes (if any)</label>
    <input type="text" class="form-control" name="notes" aria-describedby="companyname" placeholder="notes">
    
  </div>
  
  <button type="submit" class="btn btn-primary" value="Upload">Submit</button>
</form>
<br>
<br>

<?php include_once("../includes/footer.php") ?>