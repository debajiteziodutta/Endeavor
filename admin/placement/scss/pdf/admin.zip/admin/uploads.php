
<?php include_once("../includes/header.php");

include("../connection/db1.php");

$targetfolder = "uploads/" .basename($_FILES['file']['name']);

$file= $_FILES['file']['name'];
$department= $_POST['department'];
$company= $_POST['companyname1'];
$ttopic= $_POST['traningtopic1'];
$prerequisites= $_POST['prerequisites'];
$startdate= $_POST['startdate'];
$tenure= $_POST['trainingtime'];
$companycontact= $_POST['companycontact'];
$notes= $_POST['notes'];

//print "$department";
$query = "INSERT INTO training(`department`, `Company_name`, `training_topic`, `Prerequisites`, `training_details`, `Starting_date`, `tenure`, `details_of_company`, `notes`) VALUES ('$department','$company','$ttopic','$prerequisites','$file','$startdate','$tenure','$companycontact','$notes')"; 
$result= mysqli_query($conn, $query);

if($result)
{
    print "success";
}
else{
    print "failure";
}

print_r ($_FILES['file']);
if(move_uploaded_file($_FILES['file']['tmp_name'], $targetfolder))
{

    echo "The file ".basename( $_FILES['file']['name']). "is uploaded";

}
else {

    echo "Problem uploading file";

}

include_once("../includes/header.php"); ?>